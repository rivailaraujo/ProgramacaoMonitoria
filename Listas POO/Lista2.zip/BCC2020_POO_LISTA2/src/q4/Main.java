package q4;

public class Main {
	
	public static void main(String[] args){
		Circulo circulo1 = new Circulo(3);
		circulo1.area();
		circulo1.circunferencia();
		circulo1.diametro();
		Trapezio trapezio1 = new Trapezio(8,16,3);
		trapezio1.area();
		trapezio1.perimetro(5, 5);
	}

}
