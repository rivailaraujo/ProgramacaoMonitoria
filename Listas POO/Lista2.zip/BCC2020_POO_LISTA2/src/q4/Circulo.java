package q4;

public class Circulo {
	private int raio;
	private final double PI = 3.14;
	
	public Circulo(int raio) {
		this.raio = raio;
	}
	
	public void diametro() {
		System.out.println(2*raio);
	}
	
	public void circunferencia() {
		System.out.println(2*PI*raio);
	}
	
	public void area() {
		System.out.println(PI*(raio*raio));
	}
}
