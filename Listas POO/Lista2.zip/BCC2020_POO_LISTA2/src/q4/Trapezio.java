package q4;

public class Trapezio {
	private int base_menor;
	private int base_maior;
	private int altura;
	
	public Trapezio(int base_menor, int base_maior, int altura) {
		this.base_menor = base_menor;
		this.base_maior = base_maior;
		this.altura = altura;
	}
	
	public void area(){
		System.out.println(((this.base_maior+this.base_menor)*this.altura)/2);
		
	}
	
	public void perimetro(int l1, int l2) {
		System.out.println(this.base_menor + this.base_maior + l1 + l2);
	}
}
