package q1;


public class Main {
	public static void main(String[] args){
		Lampada lampada1 = new Lampada();
		lampada1.mostrar();
		lampada1.ligar();
	}
}
