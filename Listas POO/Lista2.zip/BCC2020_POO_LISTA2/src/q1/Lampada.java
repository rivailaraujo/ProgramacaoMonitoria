package q1;

public class Lampada {
    boolean luz = false;
    int quantasVezes = 0;
   
    public Lampada(){
        
    }
    
    public void mostrar(){
        System.out.println(luz);
    }
    
    public void ligar(){
        if(quantasVezes < 100){
            luz = true;
        } else {
            luz = false;
            System.out.println("Lampada queimada!");
        }
        
        quantasVezes = quantasVezes + 1; 
        
    }
}