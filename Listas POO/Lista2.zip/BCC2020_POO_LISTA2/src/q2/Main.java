package q2;

public class Main {
	
	public static void main(String[] args){
		Porta porta1 = new Porta(10,10,10);
		
		System.out.println(porta1.destrancar());
		System.out.println(porta1.abrir());
	}

}
