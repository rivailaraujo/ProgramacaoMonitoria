package q2;

public class Porta {
	
	private Boolean aberta = false;
	private Boolean trancada = false;
	private int altura;
	private int largura;
	private int profundidade;
	
	public Porta (int altura, int largura, int profundidade) {
		this.altura = altura;
		this.largura = largura;
		this.profundidade = profundidade;
	}
	
	public String destrancar() {
		
		if (this.trancada == true) {
			this.trancada = false;
			return "Porta Destrancada";
		}else {
			return "Porta Destrancada";
		}
	}
	
	public String trancar() {
		
		if (this.trancada == false) {
			this.trancada = true;
			this.fechar();
			return "Porta Trancada";
		}else {
			return "Porta Trancada";
		}
	}
	
	public String abrir() {
		if(this.aberta == true) {
			return "Porta Ja Aberta";
		}else if(this.trancada == true){
			return "Porta Trancada, Por favor destranque!";
		}else {
			return "Porta Aberta";
		}
	}
	
	public String fechar() {
		if(this.aberta == false) {
			return "Porta Ja Fechada";
		}else if(this.trancada == true){
			return "Porta Trancada e ja Fechada";
		}else {
			return "Porta Fechada";
		}
	}
	
	
}

