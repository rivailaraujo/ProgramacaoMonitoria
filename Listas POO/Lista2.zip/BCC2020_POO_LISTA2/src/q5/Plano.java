package q5;
import java.lang.Math;

public class Plano {
	private int ponto1[] = new int[2];
	private int ponto2[] = new int[2];
	private int ponto3[] = new int[2];
	private double distancia1, distancia2, distancia3;
	
	public Plano(int ponto1[], int ponto2[], int ponto3[]) {
		this.ponto1[0] = ponto1[0]; this.ponto1[1] = ponto1[1];
		this.ponto2[0] = ponto2[0]; this.ponto2[1] = ponto2[1];
		this.ponto3[0] = ponto3[0]; this.ponto3[1] = ponto3[1];
	}
	public void distancia() {
		this.distancia1 = Math.sqrt( (Math.pow(ponto2[0] - ponto1[0],2)) + (Math.pow(ponto2[1] - ponto1[1],2)) );
		this.distancia2 = Math.sqrt( (Math.pow(ponto3[0] - ponto1[0],2)) + (Math.pow(ponto3[1] - ponto1[1],2)) );
		this.distancia3 = Math.sqrt( (Math.pow(ponto3[0] - ponto2[0],2)) + (Math.pow(ponto3[1] - ponto2[1],2)) );
		System.out.println("Distancia P1 a P2: "+this.distancia1);
		System.out.println("Distancia P1 a P3: "+this.distancia2);
		System.out.println("Distancia P2 a P3: "+this.distancia3);
	}
	
	public void verficaTriangulo() {
		//this.distancia1 = 5;
		//this.distancia2 = 10;
		//this.distancia3 = 9;
		if(Math.abs(this.distancia2 - this.distancia3) < this.distancia1 && this.distancia1 < (this.distancia2 + this.distancia3)){
			if(Math.abs(this.distancia1 - this.distancia3) < this.distancia2 && this.distancia2 < (this.distancia1+this.distancia3)) {
				if(Math.abs(this.distancia1 - this.distancia2) < this.distancia3 && this.distancia3 < (this.distancia1 + this.distancia2)) {
					System.out.println("É Triangulo");
				}else {
					System.out.println("Não é Triangulo");
				}
			}else {
				System.out.println("Não é Triangulo");
			}
		}else {
			System.out.println("Não é Triangulo");
		}
	}
}
