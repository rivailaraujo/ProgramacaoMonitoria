package q5;

public class Main {

	public static void main(String[] args){
		int ponto1[] = {0,5};
		int ponto2[] = {1,3};
		int ponto3[] = {2,1};
		Plano plano1 = new Plano(ponto1,ponto2,ponto3);
		plano1.distancia();
		plano1.verficaTriangulo();
	}
}
