package q3;

public class Timer {
	private int tempo_maximo;
	private int contagem;
	private Boolean pausado = false;
	
	public Timer(int tempo_maximo) {
		this.tempo_maximo = tempo_maximo;
		this.contagem = this.tempo_maximo;
	}
	
	public String iniciar() {
		return "Contagem Iniciada";
	}
	
	public String pausar() {
		this.pausado = true;
		return "Contagem Pausada";
	}
	
	public String despausar() {
		if (this.pausado) {
			return "Contagem Continuada";
		}else {
			return iniciar();
		}
	}
	
	public String reiniciar() {
		this.pausado = false;
		this.contagem = this.tempo_maximo;
		return "Contagem reiniciada";
	}
}
