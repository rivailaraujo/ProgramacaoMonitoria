package q3;


public class Main {
	
	public static void main(String[] args){
		Timer time = new Timer(10);
		System.out.println(time.iniciar());
		System.out.println(time.pausar());
		System.out.println(time.despausar());
		System.out.println(time.reiniciar());
	}

}
